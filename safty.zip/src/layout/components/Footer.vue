<template>
  <div class="ban">
    <ul style="list-style:none;">
      <li>
        版权所有核工业地质局赣ICP证000000号
      </li>
      <li>
        地址：江西省南昌市北京西路160号
      </li>
      <li>
        电话: 0791-86351112
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style>
.ban ul li{
  padding-top:12px;
  font-size: 14px;
  text-align: center;
  color: #898989;
}

</style>
