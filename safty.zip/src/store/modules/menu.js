export default {
  namespaced: true,
  state: {
    menulist: []
  },
  mutations: {
    SET_MENULIST(state,list){
      state.menulist=list

    }
  },
  actions: {
    initMenuList({commit},list) {
      commit('SET_MENULIST',list)

    }
  }
}

