
import { numberInput } from './numberInput'

export default {
  install: function(Vue) {
    Vue.directive('number-input', numberInput)
  }
}
