// 自定义分类id转对应中文过滤器
import { transformClassify } from '@/utils'

export default function(id, module) {
  return transformClassify(module, id)
}
