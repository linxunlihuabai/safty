import { getRequest } from '@/utils/request'

// 主页的获取 [隐患数量趋势] 数据
export function getAllCount() {
  return getRequest('/safetyCheck/safetyCheck/getAllCount')
}
