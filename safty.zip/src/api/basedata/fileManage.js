import { postRequest, downloadRequest } from '@/utils/request'

// 附件 -> 查看
export function fileManageList(id) {
  return postRequest(`/file/fileManage/list/${id}`, {})
}

// 附件 -> 下载
export function fileDownload(id) {
  return downloadRequest(`/file/fileManage/download/${id}`)
}

