import { getRequest } from '@/utils/request'

// 获取项目列表
export function getProjectsList() {
  return getRequest('/config/getProjects')
}
