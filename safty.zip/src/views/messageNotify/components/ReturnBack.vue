<template>
  <el-row type="flex" justify="space-between" align="top">
    <el-button
      type="primary"
      size="small"
      icon="el-icon-back"
      @click="$router.back()"
    >
      返回
    </el-button>
  </el-row>
</template>

<script>
export default {

}
</script>

<style>

</style>
