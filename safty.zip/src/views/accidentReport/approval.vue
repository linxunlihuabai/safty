<template>
  <div class="app-container">
    <div class="panel">
      <div class="panel-title">
        <breadcrumb class="breadcrumb-container" />
      </div>
      <!-- 数据审批 -->

    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
