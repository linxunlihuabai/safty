<template>
  <div class="app-container">
    <div class="panel">
      <div class="panel-title">
        <breadcrumb class="breadcrumb-container" />
      </div>
      <div class="panel-main">
        <iframe src="https://mail.qq.com" frameborder="1" width="100%" height="800px" />
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.panel-main{
  position: relative;
  top: 20px;
  margin-bottom: 20px;
}
</style>
