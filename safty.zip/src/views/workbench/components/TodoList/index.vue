<template>
  <section class="todoapp">
    <!-- header -->
    <header class="header">
      <div class="new-todo">工作提醒</div>
    </header>
    <!-- main section -->
    <section class="main">
      <el-tabs v-model="activeName">
        <el-tab-pane label="注册审核" name="注册审核">
          <ul v-if="auditTodo && auditTodo.length>0" class="todo-list">
            <todo
              v-for="(todo, index) in auditTodo"
              :key="index"
              :todo="todo"
              type="audit"
              @click="handleAuditTodo"
            />
          </ul>
          <span v-else class="noTodo">暂无提醒</span>
        </el-tab-pane>
        <el-tab-pane label="未提交报表" name="未提交报表">
          <ul v-if="true" class="todo-list">
            <todo
              v-for="(todo, index) in reportTodo"
              :key="index"
              :todo="todo"
              type="report"
              @click="handleReportTodo"
            />
          </ul>
          <span v-else class="noTodo">暂无未提交报表</span>
        </el-tab-pane>
      </el-tabs>
      <!-- <label /> -->

    </section>
    <!-- footer -->
    <footer class="footer" />

    <el-dialog
      title="处理"
      :visible.sync="formDialog"
      :width="GLOBAL.DIALOG_WIDTH.MINI"
      append-to-body
      :close-on-click-modal="false"
      @closed="handleDialogClosed('form')"
    >

      <el-form
        ref="form"
        size="mini"
        :model="form"
        :label-width="GLOBAL.FORM_LABEL_WIDTH.MINI"
        :rules="formRules"
      >
        <el-form-item label="是否通过" prop="audit">
          <el-radio-group v-model="form.audit">
            <el-radio :label="1">通过</el-radio>
            <el-radio :label="0">未通过</el-radio>
          </el-radio-group>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="formDialog=false">取 消</el-button>
        <el-button type="primary" :loading="btnLoading" @click="formSubmit">确定</el-button>
      </div>
    </el-dialog>
  </section>
</template>

<script>
import Todo from './Todo.vue'
import { getAuditList, auditNopass, auditPass, checkSubmited } from '@/api/workbench/todoList'

export default {
  components: { Todo },
  data() {
    return {
      activeName: '注册审核',
      auditTodo: [],
      reportTodo: [
        { label: 'yhqkb', value: false },
        { label: 'yhzgqkb', value: false },
        { label: 'aqsczhb', type: 'shang', value: false },
        { label: 'aqsczhb', type: 'xia', value: false },
        { label: 'aqsczhb', type: 'yue', value: false }
      ],
      btnLoading: false,
      taskId: null,
      form: {
        audit: ''
      },
      formRules: {
        audit: [
          { required: true, message: '请选择是否通过', trigger: 'change' }
        ]
      }
    }
  },
  created() {
    getAuditList({}).then(res => {
      this.auditTodo = res.data.obj.list
    })
  },
  methods: {
    fetchList() {
      checkSubmited({}).then(res => {
        this.reportTodo = [
          { label: 'yhqkb', value: false },
          { label: 'yhzgqkb', value: false },
          { label: 'aqsczhb', type: 'shang', value: false },
          { label: 'aqsczhb', type: 'xia', value: false },
          { label: 'aqsczhb', type: 'yue', value: false }
        ]
        console.log(res.data.obj)
      })
    },
    handleAuditTodo(todo) {
      this.formDialog = true
      this.taskId = todo.taskId
    },
    handleReportTodo(todo) {
      const name = todo.label
      let url = ''
      if (name === 'yhqkb') {
        url = `/reportStatistics/monthView/${'隐患情况报表'}`
      } else if (name === 'yhzgqkb') {
        url = `/reportStatistics/monthView/${'隐患整改情况报表'}`
      } else if (name === 'aqsczhb') {
        const type = todo.type
        if (type === 'shang') {
          url = '/reportStatistics/halfMonthView'
        } else if (type === 'xia') {
          url = '/reportStatistics/halfMonthView'
        } else {
          url = `/reportStatistics/monthView/${'安全生产综合表'}`
        }
      }
      console.log(todo)
      this.$router.push(url)
    },
    formSubmit() {
      this.$refs.form.validate(async(valid) => {
        if (valid) {
          this.btnLoading = true
          const taskId = this.taskId
          if (this.form.audit == 0) {
            await auditNopass(taskId)
          } else if (this.form.audit == 1) {
            await auditPass(taskId)
          }
          this.btnLoading = false
          this.formDialog = false
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss">
  @import './index.scss';
</style>
