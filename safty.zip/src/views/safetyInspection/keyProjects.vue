<template>
  <hidden-danger :type="'重点项目'" />
</template>

<script>
import HiddenDanger from './components/hiddenDanger'

export default {
  components: {
    HiddenDanger
  }
}
</script>

<style lang="scss" scoped>

</style>
