<template>
  <hidden-danger :type="'隐患整体'" />
</template>

<script>
import HiddenDanger from './components/hiddenDanger'

export default {
  components: {
    HiddenDanger
  }
}
</script>

<style lang="scss" scoped>

</style>
