<template>
  <div class="app-container">
    <div class="panel">
      <div class="panel-title">
        <breadcrumb class="breadcrumb-container" />
      </div>
      <div style="text-align:center">
        <img
          style="height:300px;margin-top:140px;"
          src="@/assets/images/underDevelopment2.jpg"
          alt="功能模块正在开发中，敬请期待~"
          title="功能模块正在开发中，敬请期待~"
        >
        <p class="module">功能模块正在开发中，敬请期待~</p>
      </div>
    </div>
  </div></template>

<script>
export default {

}
</script>

<style>
.module{
  font-size: 20px;
}
</style>
