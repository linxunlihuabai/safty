
<template>
  <div>
    <div class="prompt zhou-prompt">
      您添加或修改的每一条数据后，数据都会重新刷新。（即：位置可能会发生变化）
    </div>
  </div>
</template>

<style scoped>
.zhou-prompt{
  width: 530px;
}
</style>
